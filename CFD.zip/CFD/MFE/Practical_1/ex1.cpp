#include "euler_solver.h";





int main()
{

    return 0;
}